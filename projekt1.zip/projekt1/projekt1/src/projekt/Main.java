package projekt;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		StudentManager manager = new StudentManager();
	
		List<Student> nacteni = DatabaseManager.nactiStudentyZDatabaze();
		for (Student s : nacteni) {
		    manager.pridejStudenta(s);
		}
		
		boolean bez = true;
		while(bez)  {
			 System.out.println("\n--- MENU ---");
	            System.out.println("1 - Pridani studenta");
	            System.out.println("2 - Zadani nove znamky");
	            System.out.println("3 - Propustit studenta");
	            System.out.println("4 - Nalezeni studenta");
	            System.out.println("5 - Dovednost studenta");
	            System.out.println("6 - Vypis vsech studentu v jednotlivych skupinach");
	            System.out.println("7 - Vypis obecneho studijního prumeru v oborech");
	            System.out.println("8 - Vypis poctu studentu v jednotlivych skupinach");
	            System.out.println("9 - Ulozeni studenta do souboru");
	            System.out.println("10 - Nacteni studenta ze souboru");
	            System.out.println("0 - Konec");
	            System.out.print("Vyber moznost: ");
	            String volba = scanner.nextLine();
	            
	            
	            switch (volba) {
                case "1":
                	System.out.print("Zadej jmeno: ");
                    String jmeno = scanner.nextLine();
                    if (jmeno.matches(".*\\d.*")) {
                        System.out.println("Jmeno nesmi obsahovat cisla.");
                        break;
                    }
                    
                    System.out.print("Zadej prijmeni: ");
                    String prijmeni = scanner.nextLine();
                    if (prijmeni.matches(".*\\d.*")) {
                        System.out.println("Prijmeni nesmi obsahovat cisla.");
                        break;
                    }
                    
                    int rok;
                    try {
                        System.out.print("Zadej rok narozeni: ");
                        rok = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatny format roku narozeni.");
                        break;
                    }

                    System.out.println("Vyber obor:");
                    System.out.println("1 - Telekomunikace");
                    System.out.println("2 - Kyberbezpecnost");
                    String obor = scanner.nextLine();

                    Student novy;
                    if (obor.equals("1")) {
                        novy = new Telekomunikace(jmeno, prijmeni, rok);
                    } else if (obor.equals("2")) {
                        novy = new Kyberbezpecnost(jmeno, prijmeni, rok);
                    } else {
                        System.out.println("Neplatny obor.");
                        break;
                    }
                    
                    manager.pridejStudenta(novy);
                    System.out.println("Student pridan.");
                    break;
                    
                case "2":
                	int idZnamka;
                    try {
                        System.out.print("Zadej ID studenta: ");
                        idZnamka = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    
                    Student studentZ = manager.najdiStudenta(idZnamka);
                    
                    if (studentZ != null) {
                    	 int znamka;
                    	    try {
                    	        System.out.print("Zadej známku (1–5): ");
                    	        znamka = Integer.parseInt(scanner.nextLine());
                    	        if (znamka < 1 || znamka > 5) {
                    	            System.out.println("Znamka musi byt v rozsahu 1 az 5.");
                    	            break;
                    	        }
                    	    } catch (NumberFormatException e) {
                    	        System.out.println("Neplatna znamka – musi byt cislo od 1 do 5.");
                    	        break;
                    	    }
                        studentZ.pridaniZnamky(znamka);
                        System.out.println("Znamka byla uspesne pridana.");
                    } else {
                        System.out.println("Student s timto ID nebyl nalezen.");
                    }
                    break;
                    
                case "3":
                	int idSmazat;
                    try {
                        System.out.print("Zadej ID studenta: ");
                        idSmazat = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    
                	boolean studentSmazat = manager.odeberStudenta(idSmazat);
                	
                	if (studentSmazat) {
						System.out.println("Student byl uspesne smazan.");
					} else {
						System.out.println("Student s timto ID neexistuje.");
					}
                    break;
                    
                case "4":
                	int idNajit;
                    try {
                        System.out.print("Zadej ID studenta: ");
                        idNajit = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    
                	    Student nalezeny = manager.najdiStudenta(idNajit);
                	    if (nalezeny != null) {
                	        System.out.println(nalezeny);  
                	    } else {
                	        System.out.println("Student s timto ID neexistuje.");
                	    }
                    break;
                    
                case "5" :
                	int idDovednost;
                    try {
                        System.out.print("Zadej ID studenta: ");
                        idDovednost = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    
                    Student studentD = manager.najdiStudenta(idDovednost);
                    if (studentD != null) {
                        studentD.provedDovednost();
                    } else {
                        System.out.println("Student s timto ID nebyl nalezen.");
                    }
                	break;
                	
                case "6" :
                	manager.vypisPodlePrijmeni();
                	break;
                	
                case "7":
                    manager.vypisObecnyStudijnyPrumer();
                    break;
                  
                case "8":
                    manager.vypisPocetStudentu();
                    break;
                    
                case "9":
                	int idUlozit;
                    try {
                        System.out.print("Zadej ID studenta, ktereho chces ulozit do souboru: ");
                        idUlozit = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    Student studentUlozit = manager.najdiStudenta(idUlozit);
                    if (studentUlozit != null) {
                        StudentManager.ulozStudentaDoSouboru(studentUlozit);
                    } else {
                        System.out.println("Student s timto ID nebyl nalezen.");
                    }
                    break;
                           
                    
                case "10":
                	int idZeSouboru;
                    try {
                        System.out.print("Zadej ID studenta, ktereho chces vypsat ze souboru: ");
                        idZeSouboru = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Neplatne ID – musi byt cislo.");
                        break;
                    }
                    StudentManager.vypisStudentaZeSouboru(idZeSouboru);
                	break;
                	       	
                case "0":
                	System.out.println("Ukladam data do databaze...");
                    DatabaseManager.ulozStudentyDoDatabaze(manager.getStudenti());
                    System.out.println("Na shledanou!");
                    bez = false;
                    break;

                default:
                    System.out.println("Neplatna volba.");
                	
	            }
	            
		}
		scanner.close();
	}
}
